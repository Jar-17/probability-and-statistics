simulate(0.02,10000);
num = sum(ans==1); 