% %case1
% subplot(1,2,1);
% f1_1=normal_function(25,30,1250,300,0);
% imagesc(f1_1);
% colormap("jet");
% xlim([1000 2000]);
% xlabel("x");
% ylabel("y");
% 
% subplot(1,2,2);
% f1_2=normal_function(75,30,1750,300,0);
% imagesc(f1_2);
% colormap("jet");
% xlim([1000 2000]);


% for i=1:100
%     for j=1000:2000
%         if(abs((f1_1(i,j)-f1_2(i,j))) <=0.005*max(f1_1))
%             db1(i,j)=1;
%         else
%             db1(i,j)=0;
%         end 
%     end
% end
% 
% imagesc(db1);
% xlim([1000 2000]);
% 
%case2
subplot(1,2,1);
f2_1=normal_function(25,20,1250,200,0);
imagesc(f2_1);
colormap("jet");
xlim([1000 2000]);
xlabel("x");
ylabel("y");

subplot(1,2,2);
f2_2=normal_function(75,30,1750,300,0);
imagesc(f2_2);
colormap("jet");
xlim([1000 2000]);
% 
% 
% for i=1:100
%     for j=1000:2000
%         if(abs((f2_1(i,j)-f2_2(i,j))) >=0.005*max(f2_1))
%             db2(i,j)=0;
%         else
%             db2(i,j)=1;
%         end 
%     end
% end
% 
% imagesc(db2);
% 
% xlim([1000 2000]);
xlabel("x");
ylabel("y");