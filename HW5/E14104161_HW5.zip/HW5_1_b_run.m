%input value
x = input('input x = ');
lumbda_mul_time = input('input lumbda_nul_time = ');

poisson_function(x,lumbda_mul_time);

%show the answer
disp('probability = ');
disp(probability);